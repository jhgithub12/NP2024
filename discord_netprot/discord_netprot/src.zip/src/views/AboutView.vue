<template>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
  <nav>
        <RouterLink to="/">Home</RouterLink>
        <RouterLink to="/about">About</RouterLink>
      </nav>
</template>

