<script setup lang="ts">
import CurrentlyOnline from '../components/CurrentlyOnline.vue'
import HelloWorld from '@/components/HelloWorld.vue';
</script>

<template>
  <div class = "center-container">
    <HelloWorld msg = "Welcome to Discord!"/>
  </div>
</template>

<style scoped>
</style>