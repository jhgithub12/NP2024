import { ref, reactive } from 'vue';
import Peer from 'simple-peer';
import Stomp from 'webstomp-client';
import SockJS from 'sockjs-client';
import axios from 'axios';

interface Message {
  username: string;
  content: string;
}

interface Channel {
  id: number;
  name: string;
}

const username = ref('');
const currentChannelId = ref<number | null>(null);
const currentSubscriptionId = ref<string | null>(null);
const content = ref('');
const userList = ref<string[]>([]);
const channelList = ref<Channel[]>([]);
const messageList = ref<Message[]>([]);
const stompClient = ref<any>(null);
const connected = ref(false);
const showApp = ref(true);
const connectionErrorMessage = ref('');
const userLoadErrorMessage = ref('');
const channelLoadErrorMessage = ref('');

const sendMessage = () => {
  if (content.value.trim() !== '') {
    send();
    content.value = "";
  }
};

const send = () => {
  if (stompClient.value && connected.value) {
    const msg = {
      username: username.value,
      content: content.value
    };
    stompClient.value.send(`/app/channels/${currentChannelId.value}/text/messages`, JSON.stringify(msg), {});
  }
};

const refreshUsers = () => {
  axios.get('http://localhost:8080/users')
    .then(response => {
      userLoadErrorMessage.value = '';
      const userListFromResponse = response.data
        .filter((user: any) => user.username !== username.value)
        .map((user: any) => user.username);
      userList.value = userListFromResponse;
    })
    .catch(() => {
      userLoadErrorMessage.value = 'Failed to load user list';
    });
};

const refreshChannels = () => {
  axios.get('http://localhost:8080/channels')
    .then(response => {
      channelLoadErrorMessage.value = ''
      channelList.value = response.data;
    })
    .catch(() => {
      channelLoadErrorMessage.value = 'Failed to load channel list'
    });
};

const subscribeToChannel = (channelId: number) => {
  if (currentChannelId.value) {
    stompClient.value.unsubscribe(currentSubscriptionId.value);
    messageList.value = [];
  }

  const subscription = stompClient.value.subscribe(`/topic/channels/${channelId}/text`, (res: any) => {
    const message = JSON.parse(res.body);
    messageList.value.push(message);
  });

  currentChannelId.value = channelId;
  currentSubscriptionId.value = subscription.id;
};

const connect = () => {
  const serverURL = "http://localhost:8080/ws";
  let socket = new SockJS(serverURL);
  stompClient.value = Stomp.over(socket);

  const headers = {
    username: username.value,
  };

  stompClient.value.connect(headers,
    () => {
      connected.value = true;
      showApp.value = false;
      refreshUsers();
      refreshChannels();

      stompClient.value.subscribe("/topic/users", (res: any) => {
        const message = JSON.parse(res.body);
        if (message.eventType === "CONNECT") {
          userList.value.push(message.username);
        }
        else {
          userList.value = userList.value.filter(username => username != message.username);
        }
      });
    },
    () => {
      connected.value = false;
      connectionErrorMessage.value = 'CONNECTION ERROR';
      showApp.value = true;
    }
  );
};
