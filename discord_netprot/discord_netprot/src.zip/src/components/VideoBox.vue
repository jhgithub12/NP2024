<script setup lang="ts">
// Props, data, methods, etc. can be defined here
</script>


<template>
    <div class="video-box">
        <!-- Video content goes here -->
    </div>
</template>



<style scoped>

</style>
  